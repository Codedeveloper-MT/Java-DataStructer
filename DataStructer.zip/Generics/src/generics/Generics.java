/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package generics;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author HP
 */
public class Generics {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Integer[]num={1,3,2,5,6};
        Character[] charLetter={'M','L','P','S'};
        
        display(num);
        display(charLetter);
        
         //applicable when the is no arraylist
        System.out.println(getValue(num));
    
        
    }
    public static <T> void display(T[]arr){
            for(T t:arr){
                System.out.println(t+"");
            }
    }
    //retut
    public static <T>T getValue(T []arr)
    {
        
        return arr[2];
        
    }  
        
    
   
    
    }

