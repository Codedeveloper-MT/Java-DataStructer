/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package generics_part2;

/**
 *
 * @author HP
 */
public class Generics_part2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
            Myname<allDetails> name=new Myname<>("thando","lebo");
            School<String> school=new School<>("Gugulethu");
            
                deaw(args);
    }
                public static <T> void deaw(T x){
                x.getClass();
            }

    
}
