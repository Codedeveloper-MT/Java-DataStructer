/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package generics_part2;

/**
 *
 * @author HP
 */
public class allDetails <T>{
    T all;

    public allDetails(T all) {
        this.all = all;
    }

    public T getAll() {
        return all;
    }
    
    
}
