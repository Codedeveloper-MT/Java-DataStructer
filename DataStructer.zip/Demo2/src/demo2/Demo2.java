
package demo2;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class Demo2 {

    public static void main(String[] args) {
        // TODO code application logic here
        
        //set and map
        //set is a collection that is not sorted
        
        Set<Integer>numb=new HashSet<>();
        
        numb.add(23);
         numb.add(34);
         numb.add(45);
         numb.add(3);
         numb.add(2);
         numb.add(1);
         
         numb.forEach(System.out::println);
         
         Set<Integer>num=new TreeSet<>();
        
        num.add(23);
         num.add(34);
         num.add(45);
         num.add(3);
         num.add(2);
         num.add(1);
         
         num.forEach(System.out::println);
        
        Map <String ,Double> marks=new HashMap<>();
        marks.put("AOP216D", 98.7);
        marks.put("SEF216D", 85.7);
        marks.put("ORS216D", 84.9);
        marks.put("ISC216D", 95.0);
        
         System.out.println(marks.keySet());
        for (String key : marks.keySet()) {
            System.out.println(key);
        }
    }
    
}
