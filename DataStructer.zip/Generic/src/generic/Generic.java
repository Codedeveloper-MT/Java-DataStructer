
package generic;


public class Generic {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        String name=new String("Thando");
        Integer Age=new Integer(45);
         
        int num1=34;
        int num2=40;
        int sum=num1+num2;
        
        diplay(name);
        diplay(Age);
        
        System.out.println(display(sum));
        
    }
    //1
    public static <T> void diplay(T details){
        
        System.out.println(details);
    }
    
    //2
    
    public static <T> T display(T answer){
        
        
        return answer;
        
        
    }
    
    
    
    
}
